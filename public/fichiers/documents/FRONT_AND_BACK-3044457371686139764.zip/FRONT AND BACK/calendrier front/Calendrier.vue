<template>
  <div id="contain">
    <div id="filters">
      <div>TBER</div>
      <select
        v-model="$filters.tber_name"
        name="selected_tber"
        @change="onChange_filter($event, 'tber_name')"
      >
        <option value="">Sélectionnez un TBER</option>
        <option
          v-for="tber in list_tber"
          v-bind:key="tber.tber_id"
          v-bind:value="tber.tber"
        >
          {{ tber.tber }}
        </option>
      </select>

      <div>Année</div>
      <select
        v-model="$filters.tber_year"
        name="selected_year"
        id="selected_year"
        style="display: block"
        @change="onChange_filter($event, 'tber_year')"
      >
        <option value="">Sélectionnez l'année</option>
        <option
          v-for="year in list_year"
          v-bind:key="year.tber_id"
          v-bind:value="year.annee"
        >
          {{ year.annee }}
        </option>
      </select>
      <div class="clearboth"></div>
    </div>
    <loading-bar v-if="isLoading" />
    <div class="clearboth_15" v-bind:style="{ display: display_tables }"></div>
    <div
      id="tables"
      v-if="!isLoading"
      v-bind:style="{ display: display_tables }"
    >
      <div id="bloc_period">
        <div class="period_type" v-bind:style="{ display: display_tables }">
          <div
            :class="`action_button_${
              filter_type === 'ferié' ? 'selection' : 'selected'
            }`"
            @click="onChangeSideBar('ferié')"
          >
            Jours Fériés
          </div>
          <div
            :class="`action_button_${
              filter_type === 'periode' ? 'selection' : 'selected'
            }`"
            @click="onChangeSideBar('periode')"
          >
            Périodes
          </div>
          <div
            :class="`action_button_${
              filter_type === 'statistiques' ? 'selection' : 'selected'
            }`"
            @click="onChangeSideBar('statistiques')"
          >
            Synthèse Calendrier
          </div>
        </div>
        <!-- FERIE -->
        <div v-if="isHolidayTabActive">
          <div class="clearboth_15 action_button_selection">
            Affectation des jours Fériés {{ year }}
          </div>
          <div id="bloc_holidays" class="grid-container">
            <div class="column">
              <div class="column-header">Date</div>
              <div class="column-content">
                <div
                  v-for="holiday in holidays"
                  :key="holiday.id"
                  class="holiday-date"
                >
                  {{ holiday.date }}
                </div>
              </div>
            </div>
            <div class="column left-align">
              <div class="column-header">Libellé</div>
              <div class="column-content">
                <div
                  v-for="holiday in holidays"
                  :key="holiday.id"
                  class="holiday-label"
                >
                  {{ holiday.label }}
                </div>
              </div>
            </div>
            <div class="column column-checkboxes">
              <div class="column-header">Fériés</div>
              <div class="column-content">
                <div
                  v-for="holiday in holidays"
                  :key="holiday.id"
                  class="holiday-production"
                >
                  <input type="checkbox" v-model="holiday.selected" />
                </div>
              </div>
            </div>
            <div class="column-footer">
              <div class="checkbox-container">
                <input
                  type="checkbox"
                  v-model="selectAllHolidays"
                  id="selectAllHolidays"
                />
                <label
                  for="selectAllHolidays"
                  class="checkbox-label"
                  @click="toggleSelectAllHolidays()"
                >
                  Sélectionner tous/aucun
                </label>
              </div>
              <div class="button-container align-right">
                <button
                  class="action_button_float"
                  @click="handleInsertJoursFeries"
                >
                  OK
                </button>
                <!-- onclikc saveHoliday a rajouter -->
                <!-- button qui va faire select depuis la DB
                  il va cherchait les dates qui sont cochés
                  SELECT 

                    
                -->
              </div>
            </div>
          </div>
        </div>

        <div v-else>
          <div class="clearboth_15 action_button_selection">
            Selection de periodes
          </div>
          <select
            v-model="period_id"
            name="selected_period"
            id="selected_period"
            @change="onChange_period($event)"
          >
            <option value="0" selected>Toutes les périodes</option>
            <option
              v-for="period in list_period"
              v-bind:key="period.period_id"
              v-bind:value="period.id"
              :style="{ backgroundColor: period.period_color }"
            >
              {{ period.period_name }}
            </option>
          </select>
          <div class="clearboth_5 action_button_selection">
            Liste des périodes
          </div>
          <div id="bloc_legend">
            <ul>
              <!-- <li style="font-weight: bold"> -->
              <!-- <div class="legend_color" style="background-color: white"></div> -->
              <!-- <div class="legend_name">Toutles les periodes</div> -->
              <!-- <div class="clearboth_5"></div> -->
              <!-- </li> -->
              <li v-for="period in list_period" v-bind:key="period.period_id">
                <div
                  class="legend_color"
                  :style="'background-color: ' + period.period_color"
                ></div>
                <div class="legend_name">{{ period.period_name }}</div>
                <div class="clearboth_5"></div>
              </li>
              <li
                style="font-weight: bold; cursor: pointer; padding-left: 26px"
                @click="newPeriod()"
              >
                + Ajouter une periode
              </li>
            </ul>
          </div>
          <div class="clearboth_15 action_button_selection">
            Type de periode
          </div>
          <div class="bloc_period_modification">
            <label for="period_name">Nom de la période</label>
            <input
              type="text"
              name="period_name"
              id="period_name"
              v-model="mod_name"
            />

            <label for="period_color">Couleur de la période</label>
            <select name="period_color" id="period_color" v-model="mod_color">
              <option value="" disabled selected>
                Sélectionnez une couleur
              </option>
              <option value="silver" style="background-color: silver">
                Gris
              </option>
              <!-- <option value="red" style="background-color: red">Rouge</option> -->
              <option value="orange" style="background-color: orange">
                Orange
              </option>
              <option value="gold" style="background-color: gold">Jaune</option>
              <option value="green" style="background-color: green">
                Vert
              </option>
              <option value="teal" style="background-color: teal">
                Bleu sarcelle
              </option>
              <option value="royalblue" style="background-color: royalblue">
                Bleu
              </option>
              <option value="olive" style="background-color: olive">
                Olive
              </option>
              <option
                value="rebeccapurple"
                style="background-color: rebeccapurple"
              >
                Violet
              </option>
              <option value="pink" style="background-color: pink">Rose</option>
            </select>

            <div class="clearboth_15"></div>
            <div
              class="action_button_float"
              @click="AddPeriod ? insertPeriod() : updatePeriod()"
            >
              {{ AddPeriod ? "Créer la periode" : "Mettre à jour" }}
            </div>
            <div class="clearboth_10"></div>
            <div class="action_button_float" @click="deletePeriod()">
              Supprimer la periode
            </div>
            <div class="clearboth_10"></div>
          </div>
        </div>
      </div>

      <!-- CALENDRIER  -->
      <div
        id="bloc_calendar"
        v-if="filter_type === 'periode' || filter_type === 'ferié'"
        v-bind:style="{ display: display_tables }"
      >
        <div class="border-t border-b border-gray-900 -mx-4 my-10 shadow-inner">
          <div class="section">
            <div
              class="flex flex-col items-center lg:flex-row lg:justify-around"
            >
              <div class="mb-12">
                <v-date-picker
                  :key="year"
                  :min-date="Date.parse(this.$filters.tber_year + '-01-01')"
                  :max-date="Date.parse(this.$filters.tber_year + '-12-31')"
                  :attributes="displayed_attr"
                  show-weeknumbers="right-inside"
                  :rows="3"
                  :columns="4"
                  :first-day-of-week="2"
                  ref="calendar"
                  v-model="range"
                  is-expanded
                  is-range
                  @input="pickRange()"
                ></v-date-picker>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        id="bloc_calendar"
        v-if="filter_type === 'statistiques'"
        v-bind:style="{ display: display_tables }"
      >
        <!-- STATISTIQUE -->
        <div class="border-t border-b border-gray-900 -mx-4 my-10 shadow-inner">
          <div class="section">
            <div
              class="flex flex-col items-center lg:flex-row lg:justify-around"
            >
              <div class="mb-12">
                <div style="display: flex">
                  <table style="flex: 1">
                    <thead>
                      <tr>
                        <th style="width: 160px !important">{{ year }}</th>
                        <th v-for="month in 12" :key="month">
                          {{ getMonthName(month) }}
                        </th>
                        <th>Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr
                        style="width: 160px !important"
                        v-for="yearData in data"
                        :key="yearData.year"
                      >
                        <td style="width: 160px !important">Global</td>
                        <td
                          v-for="monthData in yearData.months"
                          :key="monthData.month"
                        >
                          <span v-text="monthData.days"></span>
                        </td>
                        <td>{{ yearData.total }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <br />
                <div>
                  <div v-for="period in list_period" :key="period.period_id">
                    <h2
                      :style="
                        'background-color: ' +
                        period.period_color +
                        '; color: white'
                      "
                    >
                      {{ period.period_name }}
                    </h2>
                    <div style="display: flex">
                      <table style="flex: 1">
                        <thead>
                          <tr>
                            <th style="width: 160px !important">Mois</th>
                            <th>Janvier</th>
                            <th>Février</th>
                            <th>Mars</th>
                            <th>Avril</th>
                            <th>Mai</th>
                            <th>Juin</th>
                            <th>Juillet</th>
                            <th>Aout</th>
                            <th>Sept</th>
                            <th>Octb</th>
                            <th>Novemb</th>
                            <th>Decem</th>
                            <th>Total</th>
                          </tr>
                        </thead>
                        <tbody v-for="perioddd in periodd" :key="perioddd.id">
                          <tr>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              Total
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #e6f3ff;
                              "
                            >
                              {{ perioddd.total }}
                            </td>
                          </tr>
                          <tr>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              Sous-Total (L à V)
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                            <td
                              style="
                                font-weight: bold;
                                background-color: #ccebff;
                              "
                            >
                              {{ perioddd.subTotal }}
                            </td>
                          </tr>
                          <br />
                          <tr>
                            <td>Lundi</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                            <td>{{ perioddd.monday }}</td>
                          </tr>
                          <tr>
                            <td>Mardi</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                            <td>{{ perioddd.tuesday }}</td>
                          </tr>
                          <tr>
                            <td>Mercredi</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                            <td>{{ perioddd.wednesday }}</td>
                          </tr>
                          <tr>
                            <td>Jeudi</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                            <td>{{ perioddd.thursday }}</td>
                          </tr>
                          <tr>
                            <td>Vendredi</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                            <td>{{ perioddd.friday }}</td>
                          </tr>
                          <tr>
                            <td>Samedi</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                            <td>{{ perioddd.saturday }}</td>
                          </tr>
                          <tr>
                            <td style="font-weight: bold">Dimanche</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                            <td>{{ perioddd.sunday }}</td>
                          </tr>
                          <tr>
                            <td style="font-weight: bold">Férié</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                            <td>{{ perioddd.holiday }}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
#filters {
  display: flex;
  align-items: center;
}

#tables {
  width: 100%;
  padding-right: 20px;
  padding-left: 10px;
}

#bloc_calendar {
  width: 72%;
  padding-left: 20px;
  float: left;
  margin-top: 10px;
}

#bloc_period {
  margin-top: 10px;
  width: 28%;
  float: left;
  border: solid #005f7d;
  background-color: #f7f7f7;
}

#bloc_legend {
  width: 100%;
  max-height: 150px;
  overflow: auto;
  margin-top: 10px;
  float: left;
}

.bloc_period_modification {
  width: 100%;
  background-color: #f7f7f7;
  padding: 20px;
  border: 1px solid #cccccc;
}

.period_type {
  height: auto;
  display: flex !important;
  flex-wrap: wrap;
}

#bloc_legend ul li {
  list-style-type: none;
  clear: both;
  margin: 10px 0;
}

.legend_color {
  width: 26px;
  height: 26px;
  border-radius: 13px;
  float: left;
}

.legend_name {
  line-height: 26px;
  float: left;
  margin-left: 10px;
  font-weight: bold;
}

.legend_data {
  float: right;
  margin-right: 5px;
  font-weight: bold;
}

#bloc_period label {
  margin-left: auto;
  margin-right: auto;
  width: 100%;
  display: block;
  font-weight: bold;
  font-size: 18px;
}

#bloc_period select {
  margin-left: auto;
  margin-right: auto;
  width: 100%;
  padding: 10px;
  margin-top: 5px;
  margin-bottom: 10px;
  display: block;
  border: 1px solid #cccccc;
}

#bloc_period input {
  margin-left: auto;
  margin-right: auto;
  width: 100%;
  padding: 10px;
  margin-top: 5px;
  margin-bottom: 15px;
  display: block;
  border: 1px solid #cccccc;
}

.action_button_float {
  width: 100%;
  padding: 8px;
  padding-left: 20px;
  padding-right: 20px;
  background-color: #005f7d;
  color: #ffffff;
  position: relative;
  float: right;
  font-size: 18px;
  cursor: pointer;
  right: 0;
  top: 0;
  text-align: center;
}

.action_button_selection {
  height: auto;
  flex: 1;
  padding: 8px;
  padding-left: 10px;
  padding-right: 10px;
  background-color: #005f7d;
  color: #ffffff;
  font-size: 18px;
  /* cursor: pointer; */
  right: 0;
  top: 0;
  text-align: center;
}

.action_button_selected {
  flex: 1;
  padding: 8px;
  padding-left: 10px;
  padding-right: 10px;
  color: #005f7d;
  font-size: 18px;
  cursor: pointer;
  right: 0;
  top: 0;
  text-align: center;
}

#bloc_holidays {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  margin-top: 10px;
}

.column {
  flex: 1;
  margin-right: 20px;
  margin-bottom: 20px;
}

.column-header {
  font-weight: bold;
  margin-bottom: 10px;
}

.column-content {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.column-contentt {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.column-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
}

.checkbox-container {
  display: flex;
  align-items: center;
  margin-right: 10px;
}

.checkbox-label {
  margin-left: 5px;
}

.button-container {
  margin-left: 10px;
}

.button-container button {
  margin-left: 10px;
}

.holiday-date,
.holiday-label,
.holiday-production {
  margin-bottom: 20px;
}
.column-checkboxes {
  /* Ajoutez une marge inférieure personnalisée */
  margin-bottom: 10px;
}

.column-checkboxes .holiday-production {
  /* Réduisez la marge inférieure des checkboxes */
  margin-bottom: 11px;
}

/* Ajout de nouvelles règles de style */

.holiday-date {
  white-space: nowrap; /* Empêche les dates de se retourner à la ligne */
}

.holiday-label {
  white-space: nowrap; /* Empêche les libellés de se retourner à la ligne */
}

th,
td {
  border: 1px solid #ccc;
  padding: 8px;
  border-bottom: 2px solid rgba(0, 0, 0, 0.366); /* Ajout de la propriété border-bottom */
}

th {
  background-color: #f2f2f2;
  font-weight: bold;
}

.grid-container {
  display: grid;
  grid-template-columns: repeat(3, 1fr); /* 3 colonnes avec largeur égale */
  gap: 10px; /* espace entre les colonnes */
}

.left-align .column-header {
  text-align: left !important;
}
</style>

<script>
import { server } from "../../helper";
import axios from "axios";
import moment from "moment";

export default {
  name: "Calendrier",
  data() {
    return {
      displaedPeriod: {},
      selected: undefined,
      range: [],
      mod_name: "",
      mod_color: "",
      AddPeriod: false,
      filter_type: "periode",
      isLoading: false,
      isHolidayTabActive: false,
      isPeriodTabActive: true,
      year: new Date().getFullYear(),
      holidays: [
        { id: 1, date: "01/01/2023", label: "Jour de l'an" },
        { id: 2, date: "10/04/2023", label: "Lundi de Pâques" },
        { id: 3, date: "10/04/2023", label: "Fête du Travail" },
        { id: 4, date: "10/04/2023", label: "Victoire 1945" },
        { id: 5, date: "10/04/2023", label: "Ascension" },
        { id: 6, date: "10/04/2023", label: "Ascension" },
        { id: 7, date: "10/04/2023", label: "Fête nationale" },
        { id: 8, date: "10/04/2023", label: "Assomption" },
        { id: 9, date: "10/04/2023", label: "Lundi de Pâques" },
        { id: 10, date: "10/04/2023", label: "Toussaint" },
        { id: 11, date: "10/04/2023", label: "Armistice 1918" },
      ],
      data: [
        {
          months: [
            { month: 1, days: 31 },
            { month: 2, days: 28 },
            { month: 3, days: 31 },
            { month: 4, days: 30 },
            { month: 5, days: 31 },
            { month: 6, days: 30 },
            { month: 7, days: 31 },
            { month: 8, days: 31 },
            { month: 9, days: 30 },
            { month: 10, days: 31 },
            { month: 11, days: 30 },
            { month: 12, days: 31 },
          ],
          total: 365,
        },
      ],
      periodd: [
        {
          id: 1,
          total: 24,
          subTotal: 18,
          monday: 4,
          tuesday: 3,
          wednesday: 3,
          thursday: 2,
          friday: 6,
          saturday: 7,
          sunday: 5,
          holiday: 3,
        },
      ],
      displayedPeriodDates: [],
      selectAllHolidays: false,
      displayed_attr: [],
      list_tber: this.getTberByEmail(),
      list_year: [],
      list_period: [],
      activePeriod: {},
      period_id: undefined,
      display_tables: "none",
    };
  },

  created() {
    if (this.activePeriod) {
      this.displayedPeriodDates = [...this.activePeriod.dates];
    }
    this.calculateMonthsDays();
    this.fetchHolidays(this.year);
  },
  watch: {
    period_id() {
      if (this.period_id == 0) {
        this.list_period.forEach((e) => {
          this.displayed_attr.push({
            period_id: e.id,
            dates: e.dates,
            highlight: {
              fillMode: "light",
              style: {
                "background-color": e.period_color,
              },
            },
          });
        });
        this.mod_name = "";
        this.mod_color = "";
      } else {
        this.activePeriod = this.list_period.find(
          (e) => e.id == this.period_id
        );
        if (this.activePeriod) {
          this.mod_name = this.activePeriod.period_name;
          this.mod_color = this.activePeriod.period_color;
        }
        this.updateDisplayedCalendar();
      }
    },
  },
  methods: {
    pickRange() {
      const start = new Date(this.range.start);
      const end = new Date(this.range.end);
      const pickedDays = [];
      for (let d = start; d <= end; d.setDate(d.getDate() + 1)) {
        const date = d.toISOString().slice(0, 10);
        pickedDays.push(date);
        if (!this.activePeriod.dates.includes(date)) {
          this.activePeriod.dates.push(date);
          this.displayedPeriodDates.push(date); // Ajoutez cette ligne pour mettre à jour les dates affichées
        } else {
          const index = this.activePeriod.dates.indexOf(date);
          this.activePeriod.dates.splice(index, 1);
          this.displayedPeriodDates.splice(index, 1); // Ajoutez cette ligne pour mettre à jour les dates affichées
        }
      }
      this.updatePeriodDays(pickedDays);
      this.range = [];
      this.$refs.calendar.value_ = null;
    },
    newPeriod() {
      this.period_id = 0;
      this.AddPeriod = true;
      this.mod_name = "";
      this.mod_color = "";
    },
    updateDisplayedCalendar(period) {
      this.displayed_attr.push({
        dates: period.dates,
        period_id: period.id,
        highlight: {
          fillMode: "light",
          style: {
            "background-color": period.period_color,
          },
        },
      });
      this.displayedPeriodDates = [...period.dates];
    },
    async getTberByEmail() {
      this.isLoading = true;
      return await axios
        .get(
          server.baseURL +
            `/api/filtres/getTberByEmail/` +
            this.$cookie.get("mail")
        )
        .then((result) => {
          this.isLoading = false;
          this.list_tber = result.data;
          if (result.data.length == 0) {
            alert(
              "Vous n'avez accès à la modification d'aucun TBER, merci de voir avec un responsable Smartdata pour corriger ce problème."
            );
          }
        });
    },
    async getAnneeByTber(tber) {
      if (tber) {
        return await axios
          .get(server.baseURL + `/api/filtres/getAnneeByTber/` + tber)
          .then((result) => {
            this.list_year = result.data;
            const year = (Number(this.list_year[0].annee) + 1).toString();
            const id =
              this.list_year[0].tber_id.slice(0, -2) + year.substring(2);
            this.list_year.unshift({ annee: year, tber_id: id });
          });
      } else {
        return [];
      }
    },
    async onChange_period(event) {
      this.AddPeriod = event.target.value == 0;
      this.activePeriod = this.list_period.find(
        (e) => e.id == event.target.value
      );
      this.period_id = event.target.value;
    },
    async load_all_period() {
      this.isLoading = true;
      return await axios
        .get(
          server.baseURL +
            "/api/calendrier/getCalendrierByTber/" +
            this.$filters.tber_id
        )
        .then((result) => {
          this.isLoading = false;
          result.data.forEach((dates) => {
            const index = this.list_period.findIndex(
              (e) => e.id == dates.period_id
            );
            if (index > -1) {
              this.list_period[index].dates.push(dates.date.slice(0, 10));
            }
          });
          this.period_id = 0;
          this.AddPeriod = true;
        });
    },
    async getPeriodByTber(tberId) {
      this.list_period = [];
      try {
        const list_period = await axios.get(
          server.baseURL + "/api/calendrier/getPeriodByTber/" + tberId
        );
        list_period.data.forEach((p) => {
          this.list_period.push({ ...p, dates: [] });
        });

        // Mettre à jour displayed_attr avec les dates affichées
        this.displayed_attr = this.list_period.map((period) => ({
          dates: period.dates,
          period_id: period.id,
          highlight: {
            fillMode: "light",
            style: {
              "background-color": period.period_color,
            },
          },
        }));

        this.load_all_period();
      } catch (error) {
        throw new Error("Error getting period by tber");
      }
    },
    async insertPeriod() {
      var period_name = document.getElementById("period_name").value;
      var period_color_select = document.getElementById("period_color");
      var period_color =
        period_color_select.options[period_color_select.selectedIndex].value;
      if (period_name != "" && period_color != "") {
        return await axios
          .get(
            server.baseURL +
              "/api/calendrier/insertPeriod/" +
              this.$filters.tber_id +
              "/" +
              period_name +
              "/" +
              period_color
          )
          .then((result) => {
            const newPeriod = {
              modification_date: new Date(),
              period_name,
              tber_id: this.$filters.tber_id,
              period_color,
              id: result.data,
              dates: [],
            };
            this.list_period.push(newPeriod);
            this.updateDisplayedCalendar(newPeriod);
            this.period_id = result.data;
            this.mod_name = "";
            this.mod_color = "";
          });
      }
    },
    async updatePeriod() {
      var period_name = document.getElementById("period_name").value;
      var period_color_select = document.getElementById("period_color");
      var period_color =
        period_color_select.options[period_color_select.selectedIndex].value;
      if (period_name != "" && period_color != "") {
        return await axios
          .get(
            server.baseURL +
              "/api/calendrier/updatePeriod/" +
              this.period_id +
              "/" +
              period_name +
              "/" +
              period_color
          )
          .then(() => {
            alert("La période a été mise à jour !");
            this.activePeriod.period_color = period_color;
            this.activePeriod.period_name = period_name;
          });
      }
    },
    async deletePeriod() {
      this.updatePeriodDays(this.activePeriod.dates);
      return await axios
        .get(server.baseURL + "/api/calendrier/deletePeriod/" + this.period_id)
        .then(() => {
          const newList = this.list_period.filter(
            (e) => e.id != this.period_id
          );
          this.list_period = newList;
          this.displayed_attr = this.displayed_attr.filter(
            (attr) => attr.period_id != this.period_id
          );
          this.period_id = 0;
          alert("La période a été supprimé");
        });
    },
    async updatePeriodDays(pickedDays) {
      var days_list = "";
      pickedDays.forEach((day) => {
        if (days_list != "") {
          days_list += ",";
        }
        days_list += day;
      });
      if (days_list != "") {
        return await axios
          .get(
            `${server.baseURL}/api/calendrier/updateCalendrierByPeriod/${this.activePeriod.id}/${days_list}`
          )
          .then((result) => {
            console.log(result);
          });
      }
    },
    onChangeSideBar(selection) {
      if (selection === "ferié") {
        this.isHolidayTabActive = true;
        this.isPeriodTabActive = false;
        this.isStatisticsTabActive = false;
      } else if (selection === "periode") {
        this.isHolidayTabActive = false;
        this.isPeriodTabActive = true;
        this.isStatisticsTabActive = false;
        // this.updateTableData();
      } else if (selection === "statistiques") {
        this.isHolidayTabActive = false;
        this.isPeriodTabActive = false;
        this.isStatisticsTabActive = true;
      }
      this.filter_type = selection;
    },
    async onChange_filter(event, type) {
      this.rowsParametre = [];
      if (type == "tber_name") {
        this.getAnneeByTber(event.target.value);
        this.display_tables = "none";
        this.$filters.tber_name = event.target.value;
        this.$filters.tber_id = "";
        this.$filters.tber_year = "";
      }
      if (type == "tber_year") {
        this.display_tables = "none";
        this.year = event.target.value;
        this.$filters.tber_year = event.target.value;
        this.$filters.tber_id = this.list_year.filter(
          (e) => e.annee == event.target.value
        )[0].tber_id;
        this.updateTableData();
        await this.fetchHolidays(this.year);
      }
      if (this.$filters.tber_id && this.$filters.tber_year) {
        this.display_tables = "block";
        this.year = event.target.value;
        this.getPeriodByTber(this.$filters.tber_id);
      }
    },
    async fetchHolidays(year) {
      try {
        const response = await fetch(
          `https://date.nager.at/Api/v2/PublicHolidays/${year}/FR`
        );
        const holidays = await response.json();

        const formattedHolidays = holidays.map((holiday) => {
          const formattedDate = moment(holiday.date).format("DD-MM-YYYY");
          return {
            date: formattedDate,
            label: holiday.localName,
          };
        });

        this.holidays = formattedHolidays;
      } catch (error) {
        console.error(error);
      }
    },
    getMonthName(month) {
      // Fonction pour récupérer le nom du mois à partir du numéro du mois
      const monthNames = [
        "Janvier",
        "Février",
        "Mars",
        "Avril",
        "Mai",
        "Juin",
        "Juillet",
        "Aout",
        "Sept",
        "Octob",
        "Novemb",
        "Decem",
      ];
      return monthNames[month - 1];
    },
    async updateTableData() {
      const year = parseInt(this.$filters.tber_year);

      // Calcul des jours par mois en fonction de l'année sélectionnée
      const isLeapYear = this.isLeapYear(year);
      const daysInMonth = isLeapYear
        ? [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        : [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

      const months = daysInMonth.map((days, index) => {
        return { month: index + 1, days };
      });

      const total = daysInMonth.reduce((sum, days) => sum + days, 0);

      this.data = [{ year: year, months: months, total: total }];
    },
    isLeapYear(year) {
      return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    },
    async insertJoursFeries(tberId, dates, year) {
      const promises = dates.map((date) =>
        axios.get(
          `${server.baseURL}/api/calendrier/insertJoursFeries/${tberId}/${date}/${year}`
        )
      );

      await Promise.all(promises);
    },

    // Action sur le bouton d'insertion des jours fériés
    async handleInsertJoursFeries() {
      const tberId = this.$filters.tber_id;
      const selectedHolidays = this.holidays.filter(
        (holiday) => holiday.selected
      );
      const dates = selectedHolidays.map((holiday) => holiday.date);

      try {
        await this.insertJoursFeries(tberId, dates, this.year);
        alert("Jours fériés insérés avec succès.");
      } catch (error) {
        console.log(error);
        alert("Erreur lors de l'insertion des jours fériés." + error);
      }
    },
  },
  mounted() {
    if (this.$cookie.get("mail") == null) {
      document.location.href = server.frontURL + "/connexion";
    }
    if (this.$filters.tber_id) {
      this.getAnneeByTber(this.$filters.tber_name);
      if (this.$filters.tber_year) {
        this.getPeriodByTber(this.$filters.tber_id);
        this.display_tables = "block";
      }
    }
    // if (this.year !== null) {
    this.getHolidaysByYear(this.year);
    // }
  },
};
</script>
