import {
  Controller,
  Get,
  Res,
  HttpStatus,
  Post,
  Body,
  Put,
  Query,
  NotFoundException,
  Delete,
  Param,
} from '@nestjs/common';
import { CalendrierService } from './calendrier.service';
import Calendrier from './calendrier.entity';

@Controller('calendrier')
export class CalendrierController {
  constructor(private readonly calendrierService: CalendrierService) {}

  @Get('insertPeriod/:tberId/:periodName/:periodColor')
  async insertPeriod(
    @Param('tberId') tberId: string,
    @Param('periodName') periodName: string,
    @Param('periodColor') periodColor: string,
  ) {
    return this.calendrierService.insertPeriod(tberId, periodName, periodColor);
  }

  @Get('updatePeriod/:periodId/:periodName/:periodColor')
  async updatePeriod(
    @Param('periodId') periodId: number,
    @Param('periodName') periodName: string,
    @Param('periodColor') periodColor: string,
  ) {
    return this.calendrierService.updatePeriod(
      periodId,
      periodName,
      periodColor,
    );
  }

  @Get('deletePeriod/:periodId')
  async deletePeriod(@Param('periodId') periodId: number) {
    return this.calendrierService.deletePeriod(periodId);
  }

  @Get('getPeriodByTber/:tberId')
  async getPeriodByTber(@Param('tberId') tberId: string) {
    return this.calendrierService.getPeriodByTber(tberId);
  }

  @Get('getCalendrierByTber/:tberId')
  async getCalendrierByTber(@Param('tberId') tberId: string) {
    return this.calendrierService.getCalendrierByTber(tberId);
  }

  @Get('getPeriodById/:periodId')
  async getPeriodById(@Param('periodId') periodId: number) {
    return this.calendrierService.getPeriodById(periodId);
  }

  @Get('updateCalendrierByPeriod/:periodId/:dates')
  async updateCalendrierByPeriod(
    @Param('periodId') periodId: number,
    @Param('dates') dates: string,
  ) {
    return this.calendrierService.updateCalendrierByPeriod(periodId, dates);
  }

  @Get('insertJoursFeries/:tberId/:date/:annee')
  async insertJoursFeries(
    @Param('tberId') tberId: string,
    @Param('date') date: string,
    @Param('annee') annee: string,
  ): Promise<number> {
    return this.calendrierService.insertJoursFeries(tberId, date, annee);
  }
}
