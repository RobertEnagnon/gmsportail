import { Injectable, Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import Calendrier from './calendrier.entity';
import * as momentTZ from 'moment-timezone';
import * as moment from 'moment';
import 'moment/locale/fr';

@Injectable()
export class CalendrierService {
  constructor(
    @InjectRepository(Calendrier)
    private calendrierRepository: Repository<Calendrier>,
  ) {}

  async insertPeriod(
    tberId: string,
    periodName: string,
    periodColor: string,
  ): Promise<number> {
    const queryResult = await this.calendrierRepository.query(
      `
      INSERT INTO analysis.calendrier_periode 
      (
        period_name, 
        period_color, 
        tber_id,
        modification_date
      )
      VALUES
      (
        $2, 
        $3, 
        $1,  
        NOW() 
      )
      RETURNING period_id
    `,
      [tberId, periodName, periodColor],
    );
    if (queryResult[0] && queryResult[0].period_id) {
      return queryResult[0].period_id;
    }
    throw new Error('Failed to insert period');
  }
  async updatePeriod(
    periodId: number,
    periodName: string,
    periodColor: string,
  ): Promise<Calendrier[]> {
    const calendrier = this.calendrierRepository.query(
      `
      UPDATE analysis.calendrier_periode 
      SET 
        period_name = $2, 
        period_color = $3 
      WHERE period_id = $1
    `,
      [periodId, periodName, periodColor],
    );
    if (calendrier) {
      return calendrier;
    }
    throw new Error('Post not found');
  }

  async deletePeriod(periodId: number): Promise<Calendrier[]> {
    const calendrier = this.calendrierRepository.query(
      `
      DELETE FROM analysis.calendrier_periode
      WHERE period_id = $1
    `,
      [periodId],
    );
    if (calendrier) {
      return calendrier;
    }
    throw new Error('Post not found');
  }

  async getPeriodByTber(tberId: string): Promise<Calendrier[]> {
    const selectQuery = `
      SELECT 
        period_id AS id, 
        period_name AS period_name, 
        period_color AS period_color,
        tber_id AS tber_id,
        modification_date AS modification_date
      FROM analysis.calendrier_periode 
      WHERE 
        tber_id = $1
    `;

    const periodTypes = await this.calendrierRepository.query(selectQuery, [
      tberId,
    ]);

    if (!periodTypes || periodTypes.length === 0) {
      const previousTberId =
        tberId.slice(0, -2) + (Number(tberId.substr(-2)) - 1).toString();
      const previousPeriodTypes = await this.calendrierRepository.query(
        selectQuery,
        [previousTberId],
      );

      if (previousPeriodTypes.length !== 0) {
        const promises = previousPeriodTypes.map((periodType) =>
          this.calendrierRepository.query(
            `
              INSERT INTO analysis.calendrier_periode 
              (
                period_name, 
                period_color, 
                tber_id,
                modification_date
              )
              VALUES
              (
                '${periodType.period_name}', 
                '${periodType.period_color}',
                '${tberId}',
                NOW()
              )
              RETURNING
              period_id AS id,
              period_name AS period_name,
              period_color AS period_color,
              tber_id AS tber_id,
              modification_date AS modification_date
            `,
          ),
        );
        const insertNewPeriodTypes = await Promise.all(promises);
        if (insertNewPeriodTypes) {
          return insertNewPeriodTypes as Calendrier[];
        }
      }
      return [];
    } else {
      return Promise.resolve(periodTypes);
    }
  }

  async getCalendrierByTber(tberId: string): Promise<Calendrier[]> {
    const calendrier = await this.calendrierRepository.query(
      `
      SELECT 
      calendrier_periode.period_id AS period_id,  
      calendrier_periode.period_color AS period_color,
      calendrier_jours.date AS date
    FROM analysis.calendrier_periode 
    INNER JOIN analysis.calendrier_jours ON calendrier_jours.period_id = calendrier_periode.period_id 
    WHERE 
      calendrier_periode.tber_id = $1
  `,
      [tberId],
    );

    if (calendrier) {
      const formattedCalendrier = calendrier.map((c) => ({
        period_id: c.period_id,
        period_color: c.period_color,
        date: momentTZ(c.date).tz('Europe/Paris').format('YYYY-MM-DD'),
      }));
      return formattedCalendrier;
    }

    throw new Error('Post not found');
  }

  async getPeriodById(periodId: number): Promise<Calendrier[]> {
    const calendrier = this.calendrierRepository.query(
      `
      SELECT 
        period_id,  
        period_color,
        period_name
      FROM analysis.calendrier_periode 
      WHERE period_id = $1
    `,
      [periodId],
    );
    if (calendrier) {
      return calendrier;
    }
    throw new Error('Post not found');
  }

  async updateCalendrierByPeriod(
    periodId: number,
    dates: string,
  ): Promise<Calendrier[]> {
    const dates_array = dates.split(',');

    const existingDates = await this.calendrierRepository.query(
      `
        SELECT date
        FROM analysis.calendrier_jours
        WHERE period_id = $1
      `,
      [periodId],
    );

    if (existingDates) {
      const existingDateSet = new Set(
        existingDates.map((row) =>
          momentTZ(row.date).tz('Europe/Paris').format('YYYY-MM-DD'),
        ),
      );

      const results = [];
      const newDates = dates_array.filter((date) => !existingDateSet.has(date));
      if (newDates.length > 0) {
        const insertResult = await this.calendrierRepository.query(
          `
          INSERT INTO analysis.calendrier_jours (period_id, date, jour_semaine, ferie)
          SELECT $1, unnest($2::date[]), to_char(unnest($2::date[]), 'Day'), false
          FROM generate_series(1, array_length($2::date[], 1))
        `,
          [periodId, newDates],
        );

        results.push(...newDates.map((date) => ({ date, status: 'added' })));
      }

      const datesToDelete = dates_array.filter((date) =>
        existingDateSet.has(date),
      );

      if (datesToDelete.length > 0) {
        const deleteResult = await this.calendrierRepository.query(
          `
          DELETE FROM analysis.calendrier_jours
          WHERE period_id = $1 AND date = ANY($2::date[])
        `,
          [periodId, datesToDelete],
        );

        results.push(
          ...datesToDelete.map((date) => ({ date, status: 'deleted' })),
        );
      }

      return results;
    }
    return [];
  }
  async insertJoursFeries(
    tberId: string,
    date: string,
    annee: string,
  ): Promise<number> {
    const queryResult = await this.calendrierRepository.query(
      `
      INSERT INTO analysis.jours_feries (date, annee, tber_id, active)
      VALUES ($1, $2, $3, true)
      `,
      [date, annee, tberId],
    );
  
    return queryResult[0].ferie.id;
  }

}
