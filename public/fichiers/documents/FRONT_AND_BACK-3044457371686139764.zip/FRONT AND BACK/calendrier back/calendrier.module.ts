import { Module } from '@nestjs/common';
import { DatabaseModule } from '../database/database.module';
import { calendrierProviders } from './calendrier.providers';
import { CalendrierService } from './calendrier.service';
import { CalendrierController } from './calendrier.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import Calendrier from './calendrier.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Calendrier])],
  providers: [CalendrierService],
  controllers: [CalendrierController],
})
export class CalendrierModule {}
