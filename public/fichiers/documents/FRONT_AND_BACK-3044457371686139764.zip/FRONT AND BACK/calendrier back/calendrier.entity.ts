import { Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
class Calendrier {
  @PrimaryGeneratedColumn()
  id: number;

  date: Date;

  jour_semaine: string;

  ferie: boolean;

  constructor(){
    this.ferie = false;
  }
}

export default Calendrier;
