import { Connection, Repository } from 'typeorm';
import Calendrier from './calendrier.entity';

export const calendrierProviders = [
  {
    provide: 'PARAMETRES_REPOSITORY',
    useFactory: (connection: Connection) =>
      connection.getRepository(Calendrier),
    inject: ['DATABASE_CONNECTION'],
  },
];
